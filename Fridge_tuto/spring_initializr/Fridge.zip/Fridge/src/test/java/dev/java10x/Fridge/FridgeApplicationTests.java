package dev.java10x.Fridge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FridgeApplicationTests {

	@Test
	void contextLoads() {
	}

}
